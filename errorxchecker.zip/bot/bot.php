<?php
require_once __DIR__ . "/helpers.php";
require_once __DIR__ . "/users.php";
require_once __DIR__ . "/db.php";

/* ========= CONFIG ========= */
$TOKEN = "7838201141:AAG7T5b7RXnuRLEG6fcfGuf07__5yv2Ewxk";
$API   = "https://api.telegram.org/bot{$TOKEN}/";

/* ========= TG ========= */
function tg($method, $data = []) {
    global $API;
    $ch = curl_init($API . $method);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => ["Content-Type: application/json"],
        CURLOPT_POSTFIELDS     => json_encode($data, JSON_UNESCAPED_UNICODE),
        CURLOPT_TIMEOUT        => 20
    ]);
    $res = curl_exec($ch);
    curl_close($ch);
    return $res ? json_decode($res, true) : null;
}

/* ========= UPDATE ========= */
$update = json_decode(file_get_contents("php://input"), true);
if (!$update) exit;

/* =================================================
 * CALLBACK QUERY HANDLER (GLOBAL)
 * ================================================= */
if (isset($update["callback_query"])) {

    $cb = $update["callback_query"];
    $chatId = $cb["message"]["chat"]["id"];
    $userId = $cb["from"]["id"];
    $data   = $cb["data"] ?? "";

    tg("answerCallbackQuery", [
        "callback_query_id" => $cb["id"]
    ]);

    require_once __DIR__ . "/helpers/force_join.php";

    if ($data === "recheck_join") {
        forceJoinOrBlock(
            $chatId,
            $userId,
            $cb["message"]["message_id"] // 👈 DELETE JOIN MSG IF OK
        );
        require __DIR__ . "/commands/start.php";
        exit;
    }

    require __DIR__ . "/mtxt.php";
    exit;
}

/* =================================================
 * MESSAGE
 * ================================================= */
if (!isset($update["message"])) exit;

$msg    = $update["message"];
$text   = trim($msg["text"] ?? "");
$user   = $msg["from"];
$chatId = $msg["chat"]["id"];
$userId = $user["id"];

/* ========= USER ========= */
syncUser($user);
$dbUser = refreshRole(getUser($userId));
require_once __DIR__ . "/helpers/force_join.php";

/* 🔐 FORCE JOIN FOR ALL COMMANDS */
forceJoinOrBlock($chatId, $userId);

/* ========= MAINTENANCE CHECK ========= */
$maint = $pdo->query("SELECT value FROM bot_settings WHERE `key`='maintenance'")->fetchColumn();

if ($maint === "on" && $dbUser["role"] !== "owner") {
    tg("sendMessage", [
        "chat_id"=>$chatId,
        "parse_mode"=>"HTML",
        "text" =>
"🛑 <b>Bot Under Maintenance</b>\n\n".
"Please try again later.\n\n".
"<i>@ERRORxFF</i>"
    ]);
    exit;
}

/* =================================================
 * DOCUMENT → MTXT
 * ================================================= */
if (isset($msg["document"])) {
    require __DIR__ . "/mtxt.php";
    exit;
}

/* ========= COMMAND ========= */
$cmdText = strtolower(ltrim($text, "/."));
$cmdText = explode("@", $cmdText)[0];   // support /cmd@BotName
$cmd = explode(" ", $cmdText)[0];       // remove arguments
/* =================================================
 * ROUTER
 * ================================================= */
switch ($cmd) {
    case "admin":
    if (!isOwner(getUser($userId))) {
        tg("sendMessage", [
            "chat_id"=>$chatId,
            "text"=>"❌ Admin only"
        ]);
        exit;
    }

    $token = bin2hex(random_bytes(32));
    $expires = date("Y-m-d H:i:s", time()+120);

    $pdo->prepare("
        INSERT INTO admin_tokens (user_id, token, expires_at)
        VALUES (?, ?, ?)
    ")->execute([$userId, $token, $expires]);

    $url = "https://bio-offers.site/bot/admin/token.php?t=$token";

    tg("sendMessage", [
        "chat_id"=>$chatId,
        "parse_mode"=>"HTML",
        "text"=>"🔐 <b>Admin Login</b>\n\n<a href='{$url}'>Open Admin Panel</a>\n\n⏳ Link expires in 2 minutes"
    ]);
break;


    /* ===== CORE ===== */
    case "start":
        require __DIR__ . "/commands/start.php";
        break;

case "code":
        require __DIR__ . "/commands/code.php";
        break;

case "redeem":
        require __DIR__ . "/commands/redeem.php";
        break;


    case "chk":
        require __DIR__ . "/commands/chk.php";
        break;

    case "mtxt":
        require __DIR__ . "/mtxt.php";
        break;

    /* ===== TOOLS ===== */
    case "gen":
        require __DIR__ . "/tools/gen.php";
        break;

    case "bin":
        require __DIR__ . "/tools/bin.php";
        break;

    case "fake":
        require __DIR__ . "/tools/fake.php";
        break;

    case "ip":
        require __DIR__ . "/tools/ip.php";
        break;

    case "iban":
        require __DIR__ . "/tools/iban.php";
        break;

    case "sk":
        require __DIR__ . "/tools/sk.php";
        break;

    /* ===== FILTER ===== */
    case "filter":
    case "filtervisa":
    case "filtermaster":
    case "filterbin":
        require __DIR__ . "/helpers/filter.php";
        break;

    /* ===== GATES (OWNER ONLY INSIDE FILE) ===== */
    case "addgate":
    case "rmgate":
    case "disablegate":
    case "enablegate":
    case "gates":
        require __DIR__ . "/helpers/gates.php";
        break;

    /* ===== STATS ===== */
    case "stats":
        require __DIR__ . "/helpers/stats.php";
        break;

case "adstats":
        require __DIR__ . "/helpers/adstats.php";
        break;



    /* ===== PROFILE ===== */
    case "profile":
        require __DIR__ . "/helpers/profile.php";
        break;

    /* ===== PING ===== */
    case "ping":
        require __DIR__ . "/helpers/ping.php";
        break;

case "maintenance":
    require __DIR__ . "/helpers/maintenance.php";
    break;
    /* ===== BROADCAST SYSTEM (OWNER) ===== */
case "broadcast":
case "schedule":
case "broadcasttest":
case "broadcaststats":
case "cancelbroadcast":
    require __DIR__ . "/helpers/broadcast.php";
    break;

    /* ===== UNKNOWN ===== */
    default:
        // reply ONLY if message starts with / or .
        if (preg_match('~^[/.]~', $text)) {
            tg("sendMessage", [
                "chat_id" => $chatId,
                "parse_mode" => "HTML",
                "text" => "❓ <b>Unknown command</b>\nUse /start"
            ]);
        }
        break;
}