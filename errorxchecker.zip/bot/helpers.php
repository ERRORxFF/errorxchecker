<?php

function isCommand($text, $cmd) {
    return $text === "/$cmd"
        || $text === ".$cmd"
        || str_starts_with($text, "/$cmd ")
        || str_starts_with($text, ".$cmd ");
}

function extractArgs($text) {
    $parts = explode(" ", $text, 2);
    return $parts[1] ?? "";
}

function h($text) {
    return htmlspecialchars((string)$text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function fetchJson($url) {
    $res = @file_get_contents($url);
    return $res ? json_decode($res, true) : null;
}

/* Luhn Check */
function luhnCheck($number) {
    $sum = 0;
    $alt = false;

    for ($i = strlen($number) - 1; $i >= 0; $i--) {
        $n = (int)$number[$i];

        if ($alt) {
            $n *= 2;
            if ($n > 9) $n -= 9;
        }

        $sum += $n;
        $alt = !$alt;
    }

    return ($sum % 10) === 0;
}