<?php
$pdo = new PDO(
    "mysql:host=localhost;dbname=errorwe1_tgbot;charset=utf8mb4",
    "errorwe1_ERRORxFF",
    "@ERRORxFF",
    [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]
);

/* 🔥 FORCE UTC – THIS IS REQUIRED */
$pdo->exec("SET time_zone = '+00:00'");