<?php

$args = explode(" ", extractArgs($text));
$bin = preg_replace('/\D/', '', $args[0] ?? '');

if (strlen($bin) < 6) {
    tg("sendMessage", [
        "chat_id" => $chatId,
        "text" => "❌ <b>Usage:</b> /bin 457173",
        "parse_mode" => "HTML"
    ]);
    exit;
}

/* ========= FETCH BIN DETAILS ========= */
$url = "https://bins.antipublic.cc/bins/$bin";
$json = @file_get_contents($url);

if (!$json) {
    tg("sendMessage", [
        "chat_id" => $chatId,
        "text" => "❌ <b>BIN lookup failed</b>",
        "parse_mode" => "HTML"
    ]);
    exit;
}

$data = json_decode($json, true);

if (!$data || isset($data["detail"])) {
    tg("sendMessage", [
        "chat_id" => $chatId,
        "text" => "❌ <b>BIN not found</b>",
        "parse_mode" => "HTML"
    ]);
    exit;
}

/* ========= MAP DATA (LIKE PYTHON) ========= */
$binInfo = [
    "bin"     => $data["bin"] ?? $bin,
    "country" => $data["country_name"] ?? "N/A",
    "flag"    => $data["country_flag"] ?? "",
    "vendor"  => $data["brand"] ?? "N/A",
    "type"    => $data["type"] ?? "N/A",
    "level"   => $data["level"] ?? "N/A",
    "bank"    => $data["bank"] ?? "N/A"
];

/* ========= FORMAT MESSAGE ========= */
$msg =
"📟 <b>BIN DETAILS</b>\n\n".
"<b>[π] BIN –</b> <code>{$binInfo['bin']}</code>\n".
"<b>[π] Bank –</b> <code>{$binInfo['bank']}</code>\n".
"<b>[π] Vendor –</b> <code>{$binInfo['vendor']}</code>\n".
"<b>[π] Type –</b> <code>{$binInfo['type']} {$binInfo['level']}</code>\n".
"<b>[π] Country –</b> <code>{$binInfo['country']}</code> {$binInfo['flag']}\n\n".
"<i>Developed By @ERRORxFF</i>";

/* ========= SEND ========= */
tg("sendMessage", [
    "chat_id" => $chatId,
    "text" => $msg,
    "parse_mode" => "HTML"
]);