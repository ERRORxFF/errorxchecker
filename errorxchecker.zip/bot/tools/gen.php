<?php

$argsText = extractArgs($text);

if (!$argsText) {
    tg("sendMessage", [
        "chat_id" => $chatId,
        "text" => "❌ <b>Usage:</b> /gen BIN|MM|YY|CVV [amount]",
        "parse_mode" => "HTML"
    ]);
    exit;
}

/* ========= PARSE INPUT ========= */
$parts = preg_split('/\s+/', trim($argsText));
$format = $parts[0];
$amount = isset($parts[1]) ? (int)$parts[1] : 10;
if ($amount < 1) $amount = 10;

$p = explode("|", $format);

$bin = $p[0] ?? '';
$mm  = $p[1] ?? 'rnd';
$yy  = $p[2] ?? 'rnd';
$cvv = $p[3] ?? 'rnd';

$bin = preg_replace('/\D/', '', $bin);

if (strlen($bin) < 6) {
    tg("sendMessage", [
        "chat_id" => $chatId,
        "text" => "❌ <b>Error:</b> Enter at least 6 digits BIN",
        "parse_mode" => "HTML"
    ]);
    exit;
}

/* ========= GENERATE ========= */
$cards = [];

while (count($cards) < $amount) {

    $cc = $bin;
    while (strlen($cc) < 15) {
        $cc .= rand(0, 9);
    }

    // last digit for Luhn
    for ($d = 0; $d <= 9; $d++) {
        $try = $cc . $d;
        if (luhnCheck($try)) {
            $cc = $try;
            break;
        }
    }

    if (!luhnCheck($cc)) continue;

    $m = ($mm === 'rnd') ? str_pad(rand(1, 12), 2, "0", STR_PAD_LEFT) : str_pad($mm, 2, "0", STR_PAD_LEFT);
    $y = ($yy === 'rnd') ? rand(26, 35) : $yy;
    if (strlen($y) === 2) $y = "20$y";

    $c = ($cvv === 'rnd') ? rand(100, 999) : $cvv;

    $cards[] = "$cc|$m|$y|$c";
}

/* ========= BIN LOOKUP ========= */
$binInfo = fetchJson("https://bins.antipublic.cc/bins/$bin");

/* ========= OUTPUT ========= */
$msg =
"🎰 <b>Card Generator</b>\n\n".
"[⚙] <b>Format –</b> <code>$bin|$mm|$yy|$cvv</code>\n".
"[📦] <b>Amount –</b> <code>".count($cards)."</code>\n\n";

foreach ($cards as $c) {
    $msg .= "<code>$c</code>\n";
}

if ($binInfo) {
    $msg .=
"\n[🏦] <b>Bank –</b> <code>".h($binInfo["bank"] ?? "N/A")."</code>\n".
"[💳] <b>Type –</b> <code>".h(($binInfo["type"] ?? "")." ".($binInfo["brand"] ?? ""))."</code>\n".
"[🌍] <b>Country –</b> <code>".h($binInfo["country_name"] ?? "N/A")."</code>";
}

tg("sendMessage", [
    "chat_id" => $chatId,
    "text" => $msg,
    "parse_mode" => "HTML"
]);