<?php

$args = explode(" ", extractArgs($text));
$country_code = strtolower($args[0] ?? "us");

/* ========= LOADING MESSAGE ========= */
$loading = tg("sendMessage", [
    "chat_id" => $chatId,
    "text" => "<pre>Generating Fake Identity...</pre>",
    "parse_mode" => "HTML"
]);

$mid = $loading["result"]["message_id"] ?? null;

/* ========= FETCH API ========= */
$url = "https://randomuser.me/api/?nat={$country_code}";
$json = @file_get_contents($url);

if (!$json) {
    tg("editMessageText", [
        "chat_id" => $chatId,
        "message_id" => $mid,
        "text" => "❌ Failed to fetch fake identity.",
        "parse_mode" => "HTML"
    ]);
    exit;
}

$data = json_decode($json, true);

if (!$data || empty($data["results"][0])) {
    tg("editMessageText", [
        "chat_id" => $chatId,
        "message_id" => $mid,
        "text" => "❌ Invalid country code or API error.",
        "parse_mode" => "HTML"
    ]);
    exit;
}

$f = $data["results"][0];

/* ========= MAP DATA (LIKE PYTHON) ========= */
$name    = $f["name"]["first"] . " " . $f["name"]["last"];
$gender  = ucfirst($f["gender"]);
$street  = $f["location"]["street"]["number"] . " " . $f["location"]["street"]["name"];
$city    = $f["location"]["city"];
$state   = $f["location"]["state"];
$post    = $f["location"]["postcode"];
$country = $f["location"]["country"];
$phone   = $f["phone"];
$dob     = substr($f["dob"]["date"], 0, 10);

/* ========= FORMAT MESSAGE ========= */
$msg =
"<b>⌥ [Fake Identity - ".strtoupper($country_code)."]</b> 🧾\n".
"━━━━━━━━━━━━━━━\n".
"<b>⊙ Name:</b> <code>".h($name)."</code>\n".
"<b>⊙ Gender:</b> <code>".h($gender)."</code>\n".
"<b>⊙ Street:</b> <code>".h($street)."</code>\n".
"<b>⊙ City:</b> <code>".h($city)."</code>\n".
"<b>⊙ State:</b> <code>".h($state)."</code>\n".
"<b>⊙ Pincode:</b> <code>".h($post)."</code>\n".
"<b>⊙ Country:</b> <code>".h($country)."</code>\n".
"<b>⊙ Phone:</b> <code>".h($phone)."</code>\n".
"<b>⊙ DOB:</b> <code>".h($dob)."</code>\n".
"━━━━━━━━━━━━━━━\n\n".
"<i>Developed By @ERRORxFF</i>";

/* ========= EDIT MESSAGE ========= */
tg("editMessageText", [
    "chat_id" => $chatId,
    "message_id" => $mid,
    "text" => $msg,
    "parse_mode" => "HTML"
]);