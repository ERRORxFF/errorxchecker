<?php

$iban = strtoupper(extractArgs($text));

if (!$iban) {
    tg("sendMessage", [
        "chat_id"=>$chatId,
        "text"=>"❌ <b>Usage:</b> /iban IBAN",
        "parse_mode"=>"HTML"
    ]);
    exit;
}

$data = fetchJson("https://openiban.com/validate/$iban?getBIC=true");

if (!$data || !$data["valid"]) {
    tg("sendMessage", ["chat_id"=>$chatId,"text"=>"❌ Invalid IBAN"]);
    exit;
}

$b = $data["bankData"] ?? [];

$msg =
"🏦 <b>IBAN Info</b>\n\n".
"📟 <b>IBAN:</b> <code>$iban</code>\n".
"🏦 <b>Bank:</b> <code>{$b['name']}</code>\n".
"🔑 <b>BIC:</b> <code>{$b['bic']}</code>";

tg("sendMessage", [
    "chat_id"=>$chatId,
    "text"=>$msg,
    "parse_mode"=>"HTML"
]);