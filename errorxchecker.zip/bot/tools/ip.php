<?php

$ip = extractArgs($text);

if (!filter_var($ip, FILTER_VALIDATE_IP)) {
    tg("sendMessage", [
        "chat_id"=>$chatId,
        "text"=>"❌ <b>Usage:</b> /ip 8.8.8.8",
        "parse_mode"=>"HTML"
    ]);
    exit;
}

$data = fetchJson("http://ip-api.com/json/$ip");

if (!$data || $data["status"] !== "success") {
    tg("sendMessage", ["chat_id"=>$chatId,"text"=>"❌ IP not found"]);
    exit;
}

$msg =
"🌐 <b>IP Lookup</b>\n\n".
"📟 <b>IP:</b> <code>$ip</code>\n".
"🏙 <b>City:</b> <code>{$data['city']}</code>\n".
"🌍 <b>Country:</b> <code>{$data['country']}</code>\n".
"🏢 <b>ISP:</b> <code>{$data['isp']}</code>";

tg("sendMessage", [
    "chat_id"=>$chatId,
    "text"=>$msg,
    "parse_mode"=>"HTML"
]);