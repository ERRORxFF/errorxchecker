<?php

$argsText = extractArgs($text);
$sk = trim($argsText);

if (!$sk || !preg_match('/^sk_(live|test)_/i', $sk)) {
    tg("sendMessage", [
        "chat_id" => $chatId,
        "text" => "❌ <b>Usage:</b> /sk sk_live_xxxxxxxxx",
        "parse_mode" => "HTML"
    ]);
    exit;
}

/* ========= START TIMER ========= */
$start = microtime(true);

/* ========= STRIPE REQUEST ========= */
$ch = curl_init("https://api.stripe.com/v1/balance");
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        "Authorization: Bearer {$sk}"
    ],
    CURLOPT_TIMEOUT => 15
]);

$response = curl_exec($ch);
curl_close($ch);

$end = microtime(true);
$timeTaken = number_format($end - $start, 2);

/* ========= PARSE ========= */
$data = json_decode($response, true);

if (!$data || isset($data["error"])) {
    tg("sendMessage", [
        "chat_id" => $chatId,
        "text" => "❌ <b>INVALID OR DEAD KEY</b>",
        "parse_mode" => "HTML"
    ]);
    exit;
}

/* ========= BALANCE ========= */
$available = $data["available"][0]["amount"] ?? 0;
$pending   = $data["pending"][0]["amount"] ?? 0;
$currency  = strtoupper($data["available"][0]["currency"] ?? "N/A");

/* ========= CHECK TYPE ========= */
$keyType = stripos($sk, "sk_live_") === 0 ? "𝗟𝗜𝗩𝗘 𝗞𝗘𝗬 ✅" : "𝗧𝗘𝗦𝗧 𝗞𝗘𝗬 ⚠️";

/* ========= USER ========= */
$checkerName = h($user["first_name"] ?? "User");
$checkerTag  = "𝗣𝗥𝗘𝗠𝗜𝗨𝗠"; // change if you want role-based
$countryFlag = "🇮🇳";        // optional static flag

/* ========= FORMAT MESSAGE ========= */
$msg =
"<b>{$keyType}</b>\n\n".
"[🝂] <b>𝗦𝗞 ➺</b>\n<code>{$sk}</code>\n".
"[🝂] <b>𝗥𝗲𝘀𝗽𝗼𝗻𝘀𝗲 :</b> <b>{$keyType}</b>\n".
"[🝂] <b>𝗖𝘂𝗿𝗿𝗲𝗻𝗰𝘆 :</b> <code>{$currency}</code>\n".
"[🝂] <b>𝗔𝘃𝗮𝗶𝗹𝗮𝗯𝗹𝗲 𝗕𝗮𝗹𝗮𝗻𝗰𝗲 :</b> <code>{$available}</code>\n".
"[🝂] <b>𝗣𝗲𝗻𝗱𝗶𝗻𝗴 𝗕𝗮𝗹𝗮𝗻𝗰𝗲 :</b> <code>{$pending}</code>\n".
"[🝂] <b>𝗧𝗶𝗺𝗲 𝗧𝗼𝗼𝗸 :</b> <code>{$timeTaken} Seconds</code>\n\n".
"[🝂] <b>𝗖𝗵𝗲𝗰𝗸𝗲𝗱 𝗕𝘆 ➺</b> ".
"<a href='tg://user?id={$userId}'>{$checkerName}</a> °-° {$countryFlag} [{$checkerTag}]";

/* ========= SEND ========= */
tg("sendMessage", [
    "chat_id" => $chatId,
    "text" => $msg,
    "parse_mode" => "HTML",
    "reply_to_message_id" => $msg["message_id"] ?? null
]);