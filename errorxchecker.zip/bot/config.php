<?php

define("DB_HOST", "localhost");
define("DB_NAME", "errorwe1_tgbot");
define("DB_USER", "errorwe1_ERRORxFF");
define("DB_PASS", "@ERRORxFF");

$OWNER_IDS = [
    7547264758   // your Telegram ID
];