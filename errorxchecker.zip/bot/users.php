<?php

require_once "db.php";
require_once "config.php";

/**
 * Create or update user
 */
function syncUser($user) {
    global $pdo, $OWNER_IDS;

    $id = $user["id"];
    $username = $user["username"] ?? null;
    $first_name = $user["first_name"] ?? null;

    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $exists = $stmt->fetch();

    if (!$exists) {
        $role = in_array($id, $OWNER_IDS) ? "owner" : "free";

        $stmt = $pdo->prepare("
            INSERT INTO users 
            (id, username, first_name, role, today_checks, last_reset)
            VALUES (?, ?, ?, ?, 0, ?)
        ");
        $stmt->execute([
            $id,
            $username,
            $first_name,
            $role,
            date("Y-m-d")
        ]);
    } else {
        $stmt = $pdo->prepare("
            UPDATE users 
            SET username = ?, first_name = ?, last_active = NOW()
            WHERE id = ?
        ");
        $stmt->execute([$username, $first_name, $id]);
    }
}

/**
 * Get user
 */
function getUser($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

/**
 * Reset today_checks automatically (daily)
 */
function resetDailyChecks($userId) {
    global $pdo;

    $stmt = $pdo->prepare("SELECT last_reset FROM users WHERE id=?");
    $stmt->execute([$userId]);
    $last = $stmt->fetchColumn();

    $today = date("Y-m-d");

    if ($last !== $today) {
        $pdo->prepare("
            UPDATE users 
            SET today_checks = 0, last_reset = ?
            WHERE id = ?
        ")->execute([$today, $userId]);
    }
}

/**
 * Check & auto-expire Pro
 */
function refreshRole($user) {
    global $pdo;

    if ($user["role"] === "pro" && $user["pro_expiry"] !== null) {
        if (strtotime($user["pro_expiry"]) < time()) {
            $stmt = $pdo->prepare("
                UPDATE users 
                SET role='free', pro_expiry=NULL 
                WHERE id=?
            ");
            $stmt->execute([$user["id"]]);
            $user["role"] = "free";
        }
    }
    return $user;
}

/**
 * Increment checks (TOTAL + TODAY)
 */
function addCheck($id) {
    global $pdo;

    $pdo->prepare("
        UPDATE users
        SET
            total_checks = total_checks + 1,

            today_checks = CASE
                WHEN today_check_date = CURDATE()
                THEN today_checks + 1
                ELSE 1
            END,

            today_check_date = CURDATE(),
            last_check = NOW()
        WHERE id = ?
    ")->execute([$id]);
}
/**
 * Role helpers
 */
function isOwner($user) {
    return $user["role"] === "owner";
}

function isPro($user) {
    return $user["role"] === "pro";
}