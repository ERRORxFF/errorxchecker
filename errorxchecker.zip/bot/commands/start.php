<?php
/* ========= FORCE JOIN START ========= */

$FORCE_CHANNELS = [
    "@ERRORxWEB",
    "@errorxchkgrp",
    "@errorxigcc"
];

/* ========= CHECK JOIN ========= */
function isJoined($channel, $userId) {
    $res = tg("getChatMember", [
        "chat_id" => $channel,
        "user_id" => $userId
    ]);

    if (!isset($res["ok"]) || !$res["ok"]) return false;

    $status = $res["result"]["status"] ?? "left";
    return in_array($status, ["member", "administrator", "creator"]);
}

/* ========= VERIFY ALL ========= */
$notJoined = [];

foreach ($FORCE_CHANNELS as $ch) {
    if (!isJoined($ch, $userId)) {
        $notJoined[] = $ch;
    }
}

/* ========= BLOCK ACCESS ========= */
if (!empty($notJoined)) {

    $buttons = [];
    foreach ($FORCE_CHANNELS as $ch) {
        $buttons[] = [[
            "text" => "🔔 Join ".str_replace("@", "", $ch),
            "url"  => "https://t.me/".str_replace("@", "", $ch)
        ]];
    }

    $buttons[] = [[
        "text" => "✅ Joined",
        "callback_data" => "recheck_join"
    ]];

    tg("sendMessage", [
        "chat_id" => $chatId,
        "parse_mode" => "HTML",
        "text" =>
"🔒 <b>Access Restricted</b>\n\n".
"To use this bot, you must join all required channels 👇\n\n".
"<b>Required Channels:</b>\n".
"• @ERRORxWEB\n".
"• @errorxchkgrp\n".
"• @errorxigcc\n\n".
"After joining, click <b>Joined</b>.",
        "reply_markup" => [
            "inline_keyboard" => $buttons
        ]
    ]);
    exit;
}

/* ========= SAFE NAME ========= */
$name = h(trim(
    ($user["first_name"] ?? "User") .
    (isset($user["last_name"]) ? " ".$user["last_name"] : "")
));

/* ========= START CAPTION ========= */
$caption =
"👋 <b>Welcome, {$name}</b>\n\n".
"💳 <b>CC Tools</b>\n".
"• /chk – CC Checker\n".
"• /gen – Card Generator\n".
"• /bin – BIN Lookup\n".
"• /mtxt – Mass Checker\n\n".
"🛠 <b>Utilities</b>\n".
"• /fake – Fake Identity\n".
"• /ip – IP Lookup\n".
"• /iban – IBAN Check\n".
"• /sk – Stripe Key Check\n".
"• /filter – CC Filter\n".
"• /ping – Bot Ping\n".
"• /profile – My Profile\n".
"• /stats – My Stats\n\n".
"ℹ️ Prefix: <b>/</b> or <b>.</b>\n\n".
"<i>Developed By @ERRORxFF</i>";

tg("sendPhoto", [
    "chat_id"    => $chatId,
    "photo"      => "https://i.ibb.co/zTC4qLgk/1769919085389.png",
    "caption"    => $caption,
    "parse_mode" => "HTML"
]);

exit;