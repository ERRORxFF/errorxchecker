<?php

require_once __DIR__ . "/../db.php";
require_once __DIR__ . "/../users.php";

if (!isOwner($dbUser)) {
    tg("sendMessage", [
        "chat_id" => $user["id"],
        "text" => "❌ This command is for *Owner only*.",
        "parse_mode" => "Markdown"
    ]);
    exit;
}

$days = intval(extractArgs($text));

if ($days <= 0) {
    tg("sendMessage", [
        "chat_id" => $user["id"],
        "text" => "❌ Usage:\n/code <days>",
        "parse_mode" => "Markdown"
    ]);
    exit;
}

$code = strtoupper(bin2hex(random_bytes(6)));

$stmt = $pdo->prepare("
    INSERT INTO redeem_codes (code, days)
    VALUES (?, ?)
");
$stmt->execute([$code, $days]);

tg("sendMessage", [
    "chat_id" => $user["id"],
    "text" =>
        "🎟 *Pro Code Generated*\n\n".
        "🔑 Code: `$code`\n".
        "⏳ Days: *$days*\n\n".
        "Usage:\n/redeem $code",
    "parse_mode" => "Markdown"
]);