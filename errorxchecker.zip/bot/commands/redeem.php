<?php

require_once __DIR__ . "/../db.php";
require_once __DIR__ . "/../users.php";

$code = strtoupper(trim(extractArgs($text)));

if ($code === "") {
    tg("sendMessage", [
        "chat_id" => $user["id"],
        "text" => "❌ Usage:\n/redeem <code>",
        "parse_mode" => "Markdown"
    ]);
    exit;
}

$stmt = $pdo->prepare("
    SELECT * FROM redeem_codes WHERE code = ?
");
$stmt->execute([$code]);
$redeem = $stmt->fetch();

if (!$redeem) {
    tg("sendMessage", [
        "chat_id" => $user["id"],
        "text" => "❌ Invalid redeem code.",
        "parse_mode" => "Markdown"
    ]);
    exit;
}

if ($redeem["status"] !== "active") {
    tg("sendMessage", [
        "chat_id" => $user["id"],
        "text" => "❌ This code has already been used.",
        "parse_mode" => "Markdown"
    ]);
    exit;
}

$days = intval($redeem["days"]);

if ($dbUser["role"] === "pro" && $dbUser["pro_expiry"]) {
    $base = strtotime($dbUser["pro_expiry"]);
    if ($base < time()) {
        $base = time();
    }
} else {
    $base = time();
}

$newExpiry = date("Y-m-d H:i:s", strtotime("+$days days", $base));

$pdo->prepare("
    UPDATE users 
    SET role='pro', pro_expiry=?
    WHERE id=?
")->execute([$newExpiry, $user["id"]]);

$pdo->prepare("
    UPDATE redeem_codes
    SET status='used', used_at=NOW(), used_by=?
    WHERE code=?
")->execute([$user["id"], $code]);

tg("sendMessage", [
    "chat_id" => $user["id"],
    "text" =>
        "✅ *Pro Activated!*\n\n".
        "⭐ Role: *Pro*\n".
        "⏳ Expiry: *$newExpiry*\n\n".
        "Enjoy premium access 🚀",
    "parse_mode" => "Markdown"
]);