<?php
require_once __DIR__ . "/../db.php";
require_once __DIR__ . "/../users.php";

/* ========= CONTEXT ========= */
$msg = $update["message"] ?? null;
if (!$msg) exit;

$chatId = $msg["chat"]["id"];
$userId = $msg["from"]["id"];
$user   = $msg["from"];

/* ========= USER ========= */
syncUser($user);
$dbUser = getUser($userId);

$role = $dbUser["role"] ?? "free";

/* ========= ROLE TEXT ========= */
$roleText = match ($role) {
    "owner" => "👑 OWNER",
    "pro"   => "💎 PRO",
    default => "🆓 FREE"
};

/* ========= PRO EXPIRY ========= */
$expiry = "N/A";
if (!empty($dbUser["pro_expiry"])) {
    $expiry = date("d M Y, h:i A", strtotime($dbUser["pro_expiry"]));
}

/* ========= OUTPUT ========= */
$text =
"<b>👤 USER STATS</b>\n\n".
"🆔 <b>ID:</b> <code>{$userId}</code>\n".
"👤 <b>Name:</b> ".h($dbUser["first_name"])."\n".
"🎖 <b>Role:</b> {$roleText}\n\n".
"📊 <b>CHECK STATS</b>\n".
"• <b>Total Checks:</b> <code>{$dbUser['total_checks']}</code>\n".
"• <b>Today Checks:</b> <code>{$dbUser['today_checks']}</code>\n\n".
"⏳ <b>Pro Expiry:</b> <code>{$expiry}</code>\n\n".
"<i>Developed by @ERRORxFF</i>";

tg("sendMessage", [
    "chat_id" => $chatId,
    "parse_mode" => "HTML",
    "text" => $text
]);