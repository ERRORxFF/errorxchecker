<?php
/* ========= PROFILE COMMAND ========= */

if (!$msg || !isset($msg["from"])) {
    exit;
}

$chatId = $msg["chat"]["id"];
$userId = $msg["from"]["id"];

/* ========= FETCH USER FROM DB ========= */
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$u = $stmt->fetch();

if (!$u) {
    tg("sendMessage", [
        "chat_id" => $chatId,
        "text" => "❌ User not found in database.",
        "parse_mode" => "HTML"
    ]);
    exit;
}

/* ========= ROLE ========= */
$roleText = match ($u["role"]) {
    "owner" => "👑 OWNER",
    "pro"   => "💎 PRO",
    default => "🆓 FREE"
};

/* ========= PRO EXPIRY ========= */
$expiry = "N/A";
if ($u["role"] === "pro" && !empty($u["pro_expiry"])) {
    $expiry = date("d M Y, h:i A", strtotime($u["pro_expiry"]));
}

/* ========= TELEGRAM USER INFO ========= */
$tgUser = $msg["from"];
$name = h($u["first_name"] ?? $tgUser["first_name"] ?? "User");
$username = $u["username"] ? "@".$u["username"] : "Not set";

/* ========= GET PROFILE PHOTO ========= */
$photo = tg("getUserProfilePhotos", [
    "user_id" => $userId,
    "limit" => 1
]);

$photoFileId = null;
if (!empty($photo["result"]["photos"][0][0]["file_id"])) {
    $photoFileId = $photo["result"]["photos"][0][0]["file_id"];
}

/* ========= GET BIO ========= */
$bio = "N/A";
$full = tg("getChat", ["chat_id" => $userId]);
if (!empty($full["result"]["bio"])) {
    $bio = h($full["result"]["bio"]);
}

/* ========= PROFILE TEXT ========= */
$text =
"👤 <b>USER PROFILE</b>\n\n".
"• <b>Name:</b> {$name}\n".
"• <b>Username:</b> {$username}\n".
"• <b>User ID:</b> <code>{$userId}</code>\n".
"• <b>Role:</b> {$roleText}\n".
"• <b>Total Checks:</b> {$u['total_checks']}\n".
"• <b>Pro Expiry:</b> {$expiry}\n".
"• <b>Bio:</b> {$bio}\n\n".
"<i>Developed by @ERRORxFF</i>";

/* ========= SEND ========= */
if ($photoFileId) {
    tg("sendPhoto", [
        "chat_id" => $chatId,
        "photo" => $photoFileId,
        "caption" => $text,
        "parse_mode" => "HTML"
    ]);
} else {
    tg("sendMessage", [
        "chat_id" => $chatId,
        "text" => $text,
        "parse_mode" => "HTML"
    ]);
}

exit;