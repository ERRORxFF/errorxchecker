<?php

/* ========= COMMAND ========= */
$cmdParts = explode(" ", trim($msg["text"] ?? ""));
$cmd = strtolower(ltrim($cmdParts[0] ?? "", "/."));
$arg = $cmdParts[1] ?? null;

/* ========= HELP (NO REPLY) ========= */
if (!isset($msg["reply_to_message"])) {

    if (in_array($cmd, ["filter","filtervisa","filtermaster","filterbin"])) {

        tg("sendMessage", [
            "chat_id"=>$chatId,
            "parse_mode"=>"HTML",
            "text" =>
"<b>🧹 FILTER HELP</b>\n\n".
"Reply to a <b>text</b> or <b>.txt file</b> with:\n\n".
"• <code>/filter</code> – All cards\n".
"• <code>/filtervisa</code> – VISA only\n".
"• <code>/filtermaster</code> – MasterCard only\n".
"• <code>/filterbin 411773</code> – BIN filter\n\n".
"<i>Developed By @ERRORxFF</i>"
        ]);
        exit;
    }

    return;
}

/* ========= MODE ========= */
$mode = "all";
$binFilter = null;

if ($cmd === "filtervisa") $mode = "visa";
if ($cmd === "filtermaster") $mode = "master";
if ($cmd === "filterbin" && $arg && ctype_digit($arg) && strlen($arg) >= 6) {
    $mode = "bin";
    $binFilter = $arg;
}

/* ========= PLACEHOLDER ========= */
$tmp = tg("sendMessage", [
    "chat_id"=>$chatId,
    "parse_mode"=>"HTML",
    "text"=>"<pre>---</pre>"
]);
$mid = $tmp["result"]["message_id"] ?? null;

$start = microtime(true);

/* ========= HELPERS ========= */
function normalize_year($y) {
    return strlen($y) === 4 ? substr($y, -2) : $y;
}
function isVisa($cc) {
    return str_starts_with($cc, "4");
}
function isMaster($cc) {
    $bin = intval(substr($cc,0,6));
    return ($bin >= 510000 && $bin <= 559999) ||
           ($bin >= 222100 && $bin <= 272099);
}

/* ========= EXTRACT ========= */
function extract_cards($text,$mode,$binFilter) {

    $all = [];

    foreach (preg_split("/\R/", $text) as $line) {

        $line = preg_replace('/[^\d\/\|\-\s]/u',' ',trim($line));
        if ($line === "") continue;

        preg_match_all('/\d{2,}/',$line,$nums);

        for ($i=0;$i<=count($nums[0])-4;$i++) {

            [$cc,$mm,$yy,$cvv] = array_slice($nums[0],$i,4);

            if (
                strlen($cc) >= 13 && strlen($cc) <= 16 &&
                strlen($mm) <= 2 &&
                (strlen($yy) === 2 || strlen($yy) === 4) &&
                strlen($cvv) >= 3 && strlen($cvv) <= 4
            ) {

                /* FILTERS */
                if ($mode==="visa" && !isVisa($cc)) continue;
                if ($mode==="master" && !isMaster($cc)) continue;
                if ($mode==="bin" && !str_starts_with($cc,$binFilter)) continue;

                $mm = str_pad($mm,2,"0",STR_PAD_LEFT);
                $yy = normalize_year($yy);

                $all[] = "$cc|$mm|$yy|$cvv";
                break;
            }
        }
    }

    return [$all,array_values(array_unique($all))];
}

/* ========= GET TEXT ========= */
$reply = $msg["reply_to_message"];
$textData = "";

if (isset($reply["document"])) {

    $f = tg("getFile",["file_id"=>$reply["document"]["file_id"]]);
    $path = $f["result"]["file_path"] ?? null;
    if (!$path) exit;

    $textData = file_get_contents("https://api.telegram.org/file/bot{$TOKEN}/{$path}");

} else {
    $textData = $reply["text"] ?? "";
}

if (!$textData) exit;

/* ========= PROCESS ========= */
[$all,$unique] = extract_cards($textData,$mode,$binFilter);

$total = count($all);
$uniqueCount = count($unique);
$duplicates = $total - $uniqueCount;
$timeTaken = round(microtime(true)-$start,2);

/* ========= CLEAN ========= */
if ($mid) tg("deleteMessage",["chat_id"=>$chatId,"message_id"=>$mid]);

if ($uniqueCount === 0) {
    tg("sendMessage",[
        "chat_id"=>$chatId,
        "parse_mode"=>"HTML",
        "text"=>"⚠️ <b>No valid cards found</b>"
    ]);
    exit;
}

/* ========= FILE ========= */
$label = strtoupper($mode);
$fileName = "Filtered-{$label}-".date("Ymd-His").".txt";
$filePath = __DIR__."/".$fileName;
file_put_contents($filePath,implode("\n",$unique));

$caption =
"✅ <b>FILTERING COMPLETED</b>\n\n".
"• <b>Total CC :</b> <code>{$total}</code>\n".
"• <b>Duplicate Removed :</b> <code>{$duplicates}</code>\n".
"• <b>Unique CC :</b> <code>{$uniqueCount}</code>\n".
($mode==="bin" ? "• <b>BIN :</b> <code>{$binFilter}</code>\n" : "").
"• <b>T/t :</b> <code>{$timeTaken} sec</code>\n\n".
"<i>Developed By @ERRORxFF</i>";

/* ========= SEND ========= */
$ch = curl_init("https://api.telegram.org/bot{$TOKEN}/sendDocument");
curl_setopt_array($ch,[
    CURLOPT_RETURNTRANSFER=>true,
    CURLOPT_POST=>true,
    CURLOPT_POSTFIELDS=>[
        "chat_id"=>$chatId,
        "parse_mode"=>"HTML",
        "caption"=>$caption,
        "document"=>new CURLFile(realpath($filePath))
    ]
]);
curl_exec($ch);
curl_close($ch);

unlink($filePath);
exit;