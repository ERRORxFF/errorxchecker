<?php
require_once __DIR__ . "/broadcast_utils.php";

/* OWNER ONLY */
if (!is_owner($dbUser["role"])) {
    tg("sendMessage", [
        "chat_id"=>$chatId,
        "text"=>"⛔ Owner only command",
        "parse_mode"=>"HTML"
    ]);
    exit;
}

/* ===== HELP ===== */
if ($cmd === "broadcast" && !isset($msg["reply_to_message"])) {
    tg("sendMessage", [
        "chat_id"=>$chatId,
        "parse_mode"=>"HTML",
        "text" =>
"<b>📢 BROADCAST HELP</b>\n\n".
"Reply to any message and use:\n".
"/broadcast – Instant\n".
"/schedule YYYY-MM-DD HH:MM\n".
"/broadcasttest\n".
"/broadcaststats\n".
"/cancelbroadcast\n\n".
"<i>Developed by @ERRORxFF</i>"
    ]);
    exit;
}

/* ===== TEST ===== */
if ($cmd === "broadcasttest" && isset($msg["reply_to_message"])) {
    copyAnyMessage($chatId, $msg["reply_to_message"]["message_id"], $chatId);
    exit;
}

/* ===== STATS ===== */
if ($cmd === "broadcaststats") {
    $row = $pdo->query("SELECT * FROM broadcasts ORDER BY id DESC LIMIT 1")->fetch();
    if (!$row) {
        tg("sendMessage",["chat_id"=>$chatId,"text"=>"No broadcasts"]);
        exit;
    }

    tg("sendMessage",[
        "chat_id"=>$chatId,
        "parse_mode"=>"HTML",
        "text" =>
"<b>📊 BROADCAST STATUS</b>\n\n".
"Status: {$row['status']}\n".
"Sent: {$row['sent']}\n".
"Failed: {$row['failed']}\n".
"Total: {$row['total']}"
    ]);
    exit;
}

/* ===== CANCEL ===== */
if ($cmd === "cancelbroadcast") {
    $pdo->exec("UPDATE broadcasts SET status='done' WHERE status='running'");
    tg("sendMessage",[
        "chat_id"=>$chatId,
        "text"=>"🛑 Broadcast cancelled"
    ]);
    exit;
}

/* ===== INSTANT BROADCAST ===== */
if ($cmd === "broadcast" && isset($msg["reply_to_message"])) {

    $users = getAllUsers($pdo);
    $total = count($users);

    $pdo->prepare("
        INSERT INTO broadcasts (admin_id,message_chat,message_id,status,total)
        VALUES (?,?,?,?,?)
    ")->execute([$userId,$chatId,$msg["reply_to_message"]["message_id"],"running",$total]);

    $bid = $pdo->lastInsertId();

    $statusMsg = tg("sendMessage",[
        "chat_id"=>$chatId,
        "text"=>"🚀 BROADCAST STARTED\n\nProgress: 0%",
        "parse_mode"=>"HTML"
    ]);

    $sid = $statusMsg["result"]["message_id"];
    $sent = $failed = 0;
    $lastEdit = time();

    foreach ($users as $uid) {

        $ok = copyAnyMessage($chatId,$msg["reply_to_message"]["message_id"],$uid);
        $ok ? $sent++ : $failed++;

        $percent = intval((($sent+$failed)/$total)*100);

        if (time() - $lastEdit >= 5) {
            tg("editMessageText",[
                "chat_id"=>$chatId,
                "message_id"=>$sid,
                "text"=>"🚀 BROADCAST RUNNING\n\nProgress: {$percent}%",
                "parse_mode"=>"HTML"
            ]);
            $lastEdit = time();
        }

        $pdo->prepare("UPDATE broadcasts SET sent=?,failed=? WHERE id=?")
            ->execute([$sent,$failed,$bid]);

        usleep(300000);
    }

    $pdo->prepare("UPDATE broadcasts SET status='done' WHERE id=?")->execute([$bid]);

    tg("editMessageText",[
        "chat_id"=>$chatId,
        "message_id"=>$sid,
        "parse_mode"=>"HTML",
        "text" =>
"📢 Broadcast Completed\n\n".
"✅ Sent: {$sent}\n".
"❌ Failed: {$failed}\n\n".
"<i>Developed by @ERRORxFF</i>"
    ]);
    exit;
}

/* ===== SCHEDULE ===== */
if ($cmd === "schedule" && isset($msg["reply_to_message"])) {

    $args = explode(" ",$text,2);
    if (!isset($args[1])) {
        tg("sendMessage",["chat_id"=>$chatId,"text"=>"Usage: /schedule YYYY-MM-DD HH:MM"]);
        exit;
    }

    $pdo->prepare("
        INSERT INTO broadcasts (admin_id,message_chat,message_id,status,schedule_at)
        VALUES (?,?,?,?,?)
    ")->execute([$userId,$chatId,$msg["reply_to_message"]["message_id"],"pending",$args[1]]);

    tg("sendMessage",[
        "chat_id"=>$chatId,
        "text"=>"⏳ Broadcast scheduled for {$args[1]}"
    ]);
    exit;
}