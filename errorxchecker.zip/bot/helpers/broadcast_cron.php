<?php
require_once __DIR__ . "/../db.php";
require_once __DIR__ . "/broadcast_utils.php";

$now = date("Y-m-d H:i:s");

$q = $pdo->prepare("
    SELECT * FROM broadcasts 
    WHERE status='pending' AND schedule_at<=?
");
$q->execute([$now]);

while ($b = $q->fetch()) {

    $users = getAllUsers($pdo);
    $total = count($users);
    $sent = $failed = 0;

    $pdo->prepare("UPDATE broadcasts SET status='running', total=? WHERE id=?")
        ->execute([$total,$b["id"]]);

    foreach ($users as $uid) {
        $ok = copyAnyMessage($b["message_chat"],$b["message_id"],$uid);
        $ok ? $sent++ : $failed++;
        usleep(300000);
    }

    $pdo->prepare("
        UPDATE broadcasts SET status='done',sent=?,failed=? WHERE id=?
    ")->execute([$sent,$failed,$b["id"]]);
}