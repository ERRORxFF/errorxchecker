<?php
require_once __DIR__ . "/../db.php";
require_once __DIR__ . "/../users.php";

/* ========= CONTEXT ========= */
$msg = $update["message"] ?? null;
if (!$msg || !isset($msg["text"])) exit;

$chatId = $msg["chat"]["id"];
$userId = $msg["from"]["id"];
$text   = trim($msg["text"]);

/* ========= OWNER ONLY ========= */
$user = getUser($userId);
if (($user["role"] ?? "") !== "owner") {
    tg("sendMessage", [
        "chat_id"=>$chatId,
        "parse_mode"=>"HTML",
        "text"=>"❌ <b>Owner only command</b>"
    ]);
    exit;
}

/* ========= PARSE ========= */
$raw = preg_split('/\s+/', $text);
$cmd = strtolower(ltrim(array_shift($raw), "/."));

/* ========= HELP ========= */
function gatesHelp($chatId) {
    tg("sendMessage", [
        "chat_id"=>$chatId,
        "parse_mode"=>"HTML",
        "text" =>
"<b>🚪 GATE MANAGEMENT</b>\n\n".
"➕ <b>Add Gate</b>\n".
"<code>/addgate STRIPE AUTH https://endpoint</code>\n\n".
"➖ <b>Remove Gate</b>\n".
"<code>/rmgate GATE_ID</code>\n".
"<code>/rmgate https://endpoint</code>\n\n".
"🚫 <b>Disable Gate</b>\n".
"<code>/disablegate GATE_ID</code>\n\n".
"✅ <b>Enable Gate</b>\n".
"<code>/enablegate GATE_ID</code>\n\n".
"📜 <b>List Gates</b>\n".
"<code>/gates</code>\n\n".
"<i>Developed by @ERRORxFF</i>"
    ]);
}

/* ========= COMMAND HANDLER ========= */
switch ($cmd) {

    /* ===== LIST ===== */
    case "gates":
        $rows = $pdo->query("SELECT * FROM gates ORDER BY id DESC")->fetchAll();

        if (!$rows) {
            tg("sendMessage", [
                "chat_id"=>$chatId,
                "parse_mode"=>"HTML",
                "text"=>"⚠️ <b>No gates found</b>"
            ]);
            exit;
        }

        $out = "<b>🚪 ACTIVE PAYMENT GATES</b>\n\n";
        foreach ($rows as $r) {
            $status = $r["status"] === "active" ? "✅ ACTIVE" : "🚫 DISABLED";
            $out .=
"🔹 <b>ID:</b> <code>{$r['id']}</code>\n".
"🧾 <b>Name:</b> <code>{$r['name']}</code>\n".
"🌐 <b>Endpoint:</b>\n<code>{$r['endpoint']}</code>\n".
"⚙️ <b>Status:</b> {$status}\n\n";
        }

        $out .= "<i>Developed by @ERRORxFF</i>";

        tg("sendMessage", [
            "chat_id"=>$chatId,
            "parse_mode"=>"HTML",
            "text"=>$out
        ]);
        break;

    /* ===== ADD ===== */
    case "addgate":

        if (!$raw) {
            gatesHelp($chatId);
            exit;
        }

        $endpoint = null;
        $nameParts = [];

        foreach ($raw as $part) {
            if (preg_match('~^https?://~i', $part)) {
                $endpoint = $part;
                break;
            }
            $nameParts[] = $part;
        }

        if (!$endpoint || empty($nameParts)) {
            tg("sendMessage", [
                "chat_id"=>$chatId,
                "parse_mode"=>"HTML",
                "text"=>"❌ <b>Invalid format</b>\n\n".
                        "Example:\n".
                        "<code>/addgate STRIPE AUTH https://endpoint</code>"
            ]);
            exit;
        }

        $name = trim(implode(" ", $nameParts));

        $stmt = $pdo->prepare(
            "INSERT INTO gates (name, endpoint, status) VALUES (?, ?, 'active')"
        );
        $stmt->execute([$name, $endpoint]);

        tg("sendMessage", [
            "chat_id"=>$chatId,
            "parse_mode"=>"HTML",
            "text" =>
"𝙀𝙍𝙍𝙊𝙍 𝘾𝙃𝙀𝘾𝙆𝙀𝙍:\n".
"✅ <b>Gate Added Successfully</b>\n\n".
"🧾 <b>Name:</b> <code>{$name}</code>\n".
"🌐 <b>Endpoint:</b>\n<code>{$endpoint}</code>\n\n".
"<i>Developed by @ERRORxFF</i>"
        ]);
        break;

    /* ===== REMOVE ===== */
    case "rmgate":
        $arg = $raw[0] ?? null;
        if (!$arg) {
            gatesHelp($chatId);
            exit;
        }

        if (is_numeric($arg)) {
            $pdo->prepare("DELETE FROM gates WHERE id=?")->execute([$arg]);
        } else {
            $pdo->prepare("DELETE FROM gates WHERE endpoint=?")->execute([$arg]);
        }

        tg("sendMessage", [
            "chat_id"=>$chatId,
            "parse_mode"=>"HTML",
            "text"=>"🗑️ <b>Gate removed successfully</b>"
        ]);
        break;

    /* ===== DISABLE ===== */
    case "disablegate":
        if (!isset($raw[0]) || !is_numeric($raw[0])) {
            gatesHelp($chatId);
            exit;
        }

        $pdo->prepare(
            "UPDATE gates SET status='disabled' WHERE id=?"
        )->execute([$raw[0]]);

        tg("sendMessage", [
            "chat_id"=>$chatId,
            "parse_mode"=>"HTML",
            "text"=>"🚫 <b>Gate Disabled</b> (ID: <code>{$raw[0]}</code>)"
        ]);
        break;

    /* ===== ENABLE ===== */
    case "enablegate":
        if (!isset($raw[0]) || !is_numeric($raw[0])) {
            gatesHelp($chatId);
            exit;
        }

        $pdo->prepare(
            "UPDATE gates SET status='active' WHERE id=?"
        )->execute([$raw[0]]);

        tg("sendMessage", [
            "chat_id"=>$chatId,
            "parse_mode"=>"HTML",
            "text"=>"✅ <b>Gate Enabled</b> (ID: <code>{$raw[0]}</code>)"
        ]);
        break;

    default:
        gatesHelp($chatId);
}