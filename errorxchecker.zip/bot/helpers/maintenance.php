<?php
require_once __DIR__ . "/../db.php";

/* ========= OWNER ONLY ========= */
if ($dbUser["role"] !== "owner") {
    tg("sendMessage", [
        "chat_id"=>$chatId,
        "parse_mode"=>"HTML",
        "text"=>"⛔ <b>Owner only command</b>"
    ]);
    exit;
}

/* ========= PARSE ========= */
$args = explode(" ", trim($text), 2);
$mode = strtolower($args[1] ?? "");

/* ========= HELP ========= */
if (!$mode || !in_array($mode, ["on","off"])) {
    tg("sendMessage", [
        "chat_id"=>$chatId,
        "parse_mode"=>"HTML",
        "text" =>
"🛠 <b>Maintenance Mode</b>\n\n".
"• <code>/maintenance on</code>\n".
"• <code>/maintenance off</code>\n\n".
"<i>Blocks all users except owner</i>"
    ]);
    exit;
}

/* ========= SAVE ========= */
$stmt = $pdo->prepare("REPLACE INTO bot_settings (`key`,`value`) VALUES ('maintenance',?)");
$stmt->execute([$mode]);

$status = $mode === "on" ? "ENABLED 🛑" : "DISABLED ✅";

tg("sendMessage", [
    "chat_id"=>$chatId,
    "parse_mode"=>"HTML",
    "text" =>
"⚙️ <b>Maintenance Mode</b>\n\n".
"Status: <b>{$status}</b>\n\n".
"<i>Developed by @ERRORxFF</i>"
]);