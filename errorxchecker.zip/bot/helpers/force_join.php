<?php
require_once __DIR__ . "/../db.php";

/* ========= CONFIG ========= */
$FORCE_CHANNELS = [
    "@ERRORxWEB",
    "@ERRORxCHKGRP",
    "@ERRORxIGCC"
];

$CACHE_TIME = 300; // 5 minutes

/* ========= CHECK JOIN ========= */
function checkForceJoin($chatId, $userId) {
    global $FORCE_CHANNELS;

    foreach ($FORCE_CHANNELS as $ch) {
        $res = tg("getChatMember", [
            "chat_id" => $ch,
            "user_id" => $userId
        ]);

        $status = $res["result"]["status"] ?? "left";
        if (!in_array($status, ["member","administrator","creator"])) {
            return false;
        }
    }
    return true;
}

/* ========= CACHED CHECK ========= */
function forceJoinOrBlock($chatId, $userId, $deleteMsgId = null) {
    global $pdo, $CACHE_TIME;

    $stmt = $pdo->prepare("SELECT last_check FROM users WHERE id=?");
    $stmt->execute([$userId]);
    $last = strtotime($stmt->fetchColumn());

    if ($last && (time() - $last) < $CACHE_TIME) {
        return true;
    }

    $joined = checkForceJoin($chatId, $userId);

    if ($joined) {
        $pdo->prepare("UPDATE users SET last_check=NOW() WHERE id=?")->execute([$userId]);

        // 🧹 DELETE JOIN MESSAGE ONLY IF JOINED
        if ($deleteMsgId) {
            tg("deleteMessage", [
                "chat_id" => $chatId,
                "message_id" => $deleteMsgId
            ]);
        }
        return true;
    }

    // 🚫 NOT JOINED → BLOCK ACCESS
    tg("sendMessage", [
        "chat_id" => $chatId,
        "parse_mode" => "HTML",
        "text" =>
"🔒 <b>Access Denied</b>\n\n".
"Please join all channels to use this bot 👇",
        "reply_markup" => [
            "inline_keyboard" => [
                [["text"=>"🔔 Join Channel 1","url"=>"https://t.me/ERRORxWEB"]],
                [["text"=>"🔔 Join Channel 2","url"=>"https://t.me/errorxchkgrp"]],
                [["text"=>"🔔 Join Channel 3","url"=>"https://t.me/errorxigcc"]],
                [["text"=>"✅ I Joined","callback_data"=>"recheck_join"]]
            ]
        ]
    ]);
    exit;
}