<?php
require_once __DIR__ . "/../db.php";

if (!function_exists("is_owner")) {
    function is_owner($role) {
        return $role === "owner";
    }
}

function getAllUsers(PDO $pdo) {
    return $pdo->query("SELECT id FROM users")->fetchAll(PDO::FETCH_COLUMN);
}

function copyAnyMessage($fromChat, $msgId, $toChat) {
    return tg("copyMessage", [
        "chat_id" => $toChat,
        "from_chat_id" => $fromChat,
        "message_id" => $msgId
    ]);
}