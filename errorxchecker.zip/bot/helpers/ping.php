<?php
/* ========= PING COMMAND ========= */

if (!$msg) exit;

$chatId = $msg["chat"]["id"];

/* ========= TELEGRAM PING ========= */
$start = microtime(true);

/* TEMP MESSAGE */
$tmp = tg("sendMessage", [
    "chat_id" => $chatId,
    "text" => "🚥"
]);

$end = microtime(true);

if (isset($tmp["result"]["message_id"])) {
    tg("deleteMessage", [
        "chat_id" => $chatId,
        "message_id" => $tmp["result"]["message_id"]
    ]);
}

$ping = round(($end - $start) * 1000);

/* PING LEVEL */
if ($ping <= 200) {
    $level = "Excellent ⚡";
} elseif ($ping <= 350) {
    $level = "Good ✔️";
} elseif ($ping <= 500) {
    $level = "Moderate ⚠️";
} else {
    $level = "Poor ❌";
}

/* ========= DATABASE STATUS ========= */
$dbStatus = "Offline ❌";
try {
    $pdo->query("SELECT 1");
    $dbStatus = "Online ✅";
} catch (Throwable $e) {
    $dbStatus = "Offline ❌";
}

/* ========= API HEALTH ========= */
$apiStatus = "Offline ❌";
$apiPing = "N/A";

$apiStart = microtime(true);
$apiResp = @file_get_contents("https://stripexerror.vercel.app/health");
$apiEnd = microtime(true);

if ($apiResp) {
    $json = json_decode($apiResp, true);
    if (($json["status"] ?? "") === "healthy") {
        $apiStatus = "Healthy ✅";
        $apiPing = round(($apiEnd - $apiStart) * 1000) . " ms";
    }
}

/* ========= FINAL MESSAGE ========= */
$msg =
"<pre>
┌────[ SYSTEM PING ]
│
⌯ Bot Ping  : {$ping} ms
⌯ Quality   : {$level}
│
⌯ Database  : {$dbStatus}
⌯ API       : {$apiStatus}
⌯ API Ping  : {$apiPing}
│
└────────────────────
</pre>
<i>Developed by @ERRORxFF</i>";

tg("sendMessage", [
    "chat_id" => $chatId,
    "text" => $msg,
    "parse_mode" => "HTML"
]);

exit;