<?php
require_once __DIR__ . "/../db.php";
require_once __DIR__ . "/../users.php";

/* ========= CONTEXT ========= */
$msg = $update["message"] ?? null;
if (!$msg) exit;

$chatId = $msg["chat"]["id"];
$userId = $msg["from"]["id"];

/* ========= OWNER ONLY ========= */
$dbUser = getUser($userId);
if (($dbUser["role"] ?? "") !== "owner") {
    tg("sendMessage", [
        "chat_id" => $chatId,
        "parse_mode" => "HTML",
        "text" => "❌ <b>Owner only command</b>"
    ]);
    exit;
}

/* ========= USERS ========= */
$totalUsers = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$freeUsers  = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='free'")->fetchColumn();
$proUsers   = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='pro'")->fetchColumn();
$owners     = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='owner'")->fetchColumn();

/* ========= CHECKS (GLOBAL) ========= */
$totalChecks = (int)$pdo->query("
    SELECT SUM(total_checks) FROM users
")->fetchColumn();

$todayChecks = (int)$pdo->query("
    SELECT SUM(today_checks)
    FROM users
    WHERE today_check_date = CURDATE()
")->fetchColumn();


/* ========= GATES ========= */
$activeGates   = (int)$pdo->query("SELECT COUNT(*) FROM gates WHERE status='active'")->fetchColumn();
$disabledGates = (int)$pdo->query("SELECT COUNT(*) FROM gates WHERE status='disabled'")->fetchColumn();

/* ========= REDEEM CODES ========= */
$totalCodes  = (int)$pdo->query("SELECT COUNT(*) FROM redeem_codes")->fetchColumn();
$activeCodes = (int)$pdo->query("SELECT COUNT(*) FROM redeem_codes WHERE status='active'")->fetchColumn();
$usedCodes   = (int)$pdo->query("SELECT COUNT(*) FROM redeem_codes WHERE status='used'")->fetchColumn();

/* ========= DB STATUS ========= */
$dbStatus = "ONLINE ✅";
try {
    $pdo->query("SELECT 1");
} catch (Exception $e) {
    $dbStatus = "OFFLINE ❌";
}

/* ========= OUTPUT ========= */
$text =
"<b>📊 ADMIN STATS</b>\n\n".

"👥 <b>USERS</b>\n".
"• Total: <code>{$totalUsers}</code>\n".
"• Free: <code>{$freeUsers}</code>\n".
"• Pro: <code>{$proUsers}</code>\n".
"• Owners: <code>{$owners}</code>\n\n".

"💳 <b>CHECKING (GLOBAL)</b>\n".
"• Total Checks: <code>{$totalChecks}</code>\n".
"• Today Checks: <code>{$todayChecks}</code>\n\n".

"🔑 <b>REDEEM CODES</b>\n".
"• Total Codes: <code>{$totalCodes}</code>\n".
"• Active Codes: <code>{$activeCodes}</code>\n".
"• Used Codes: <code>{$usedCodes}</code>\n\n".

"🚪 <b>GATES</b>\n".
"• Active: <code>{$activeGates}</code>\n".
"• Disabled: <code>{$disabledGates}</code>\n\n".

"🖥 <b>SYSTEM</b>\n".
"• Database: <code>{$dbStatus}</code>\n\n".

"<i>Developed by @ERRORxFF</i>";

tg("sendMessage", [
    "chat_id" => $chatId,
    "parse_mode" => "HTML",
    "text" => $text
]);